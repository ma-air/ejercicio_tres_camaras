using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveLerp : MonoBehaviour
{
    private Transform vectorPlayer;
    private GameObject posicionA;
    private GameObject posicionB;
    private Vector3 posA;
    private Vector3 posB;
    private GameObject player;
    // Start is called before the first frame update
    void Start()
    {
        
        vectorPlayer = gameObject.GetComponent<Transform>();
        posicionA = GameObject.Find("PosicionA");
        posicionB = GameObject.Find("PosicionB");
        posA = posicionA.transform.position;
        posB = posicionB.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        if(player = GameObject.Find("Player"))
        vectorPlayer.transform.position = Vector3.Lerp(posA, posB, Time.time * 0.90f);
    }
}