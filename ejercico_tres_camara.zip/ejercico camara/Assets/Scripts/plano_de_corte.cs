using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class plano_de_corte : MonoBehaviour
{
    private Camera myCamera;
    public float planoDeCorte;
    //public float tiempo;
    private GameObject player;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player");
        myCamera = GetComponent<Camera>();
        planoDeCorte = 1f;
    }

    // Update is called once per frame
    void Update()
    {
        
        transform.LookAt(player.transform);
        myCamera.nearClipPlane = planoDeCorte;
        Debug.Log(myCamera.nearClipPlane);
       // myCamera.nearClipPlane = Mathf.Lerp(0.3f, 7f, tiempo);
        //tiempo += 0.3f * Time.deltaTime;
    }
    
}
